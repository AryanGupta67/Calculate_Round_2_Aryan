import logo from './logo.svg';
import './App.css';
import Calculator from './Components/Calculator';
 
 
function App() {
  return (
     <>
   <Calculator/>
     </>
  );
}

export default App;
